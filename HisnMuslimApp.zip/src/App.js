
import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [activeTab, setActiveTab] = useState('quran');
  const surahs = Array.from({length: 114}, (_, i) => `surah_${i+1}.jpg`);

  return (
    <div dir="rtl" className="min-h-screen bg-gray-100 text-gray-900 font-sans p-4">
      <h1 className="text-3xl font-bold mb-4">المصحف (Placeholder للصور)</h1>
      <div className="grid grid-cols-4 gap-4">
        {surahs.map((img, idx) => (
          <div key={idx} className="border p-2 bg-white rounded-lg shadow">
            <p className="text-center text-sm mb-2">السورة {idx+1}</p>
            <img src={`./assets/surah_images/${img}`} alt={`السورة ${idx+1}`} className="w-full h-40 object-cover bg-gray-200" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
